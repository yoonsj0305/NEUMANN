# NEUMANN architecture gap

**v102에서 학습된 것**은 인간이 설계한 quotient observable을 받아 구성된 LP의
optimal-basis column 순위를 예측하는433-scalar 정책이다. native가 shortlist를
풀고 전체 primal/dual 검증 실패 시4m/full로 확대하는 runtime가 함께 이득을
만들었다. 이것은 보존할 bounded mechanism이다.

**현재 목표에 필요한 것**은 goal-conditioned sufficient representation
generation과 certificate-aware discovery다. 다음 연결이 아직 없다.

| 기능 | 실제 보유 | 현재 부족한 기능 |
|---|---|---|
|PERCEIVE|명시적 LP coefficient/typed goal, controlled parser, relation/proof IR|열린 원문에서 필요한 goal/관계를 learned model이 정확히 추출하는 넓은 능력 |
|REFRAME|사람 설계 quotient, fixed support, symbolic invariant·rewrite·recursive summary/decoder, guarded elimination|새로운 충분 표현 프로그램/변환 조합을 학습해 생성하고 independent motif에 적용 |
|DISCRIMINATE|original numerical verifier, exact polynomial proofs, SMT/출처-bound 실행|cheap certificate acquisition을 discovery 목표와 연결; 올바른 primal의 dual 생성 비용을 피하거나 줄이는 근거 |
|INTERNALIZE|source-bound experience/반례/cost catalog와 native procedure reuse|검증 경험으로 새 구조를 생성하는 학습, 반례에 기반한 일반화/repair, 비용 stop policy의 independent evidence |
|Economics|원래 per-stage receipts, 실패/fallback, 일부 cold/setup amortization|unknown investment·메모리·에너지와 강한 specialist를 포함한 전체 우위 |
|Capability|bounded constructed LP certificates와 작은 arithmetic/CSP/code verifiers|실제 같은 문제에서 Frontier가 해결한 gap 회복; G2미진입 |

Guarded core는 불변량을 초기 조건에 묶어 도달 영역에서 목표 충분성을
승인할 수 있다. universal 조건은 유지된다. 정확 정수7항등식의 엔지니어링
성공은 learned generator가 그 invariant를 경제적으로 발견한다는 증거가 아니다.
fixture의 native/free compiled code와 실제 운영 비용이약1배여서 학습은HOLD다.

M106의 중요한 공백은 “support에 최적 primal이 있는가”와 “그 representation의
executor가 **original** optimality certificate를 싸게 내는가”의 차이다.
Restricted dual은 제거한 모든 column의 `A^T y <= c`를 보장하지 않는다.
Original checker를 느슨하게 만들면 구조 충분성을 위조하므로 금지한다.
Optimal primal을 회수한19 first-timed attempts도 기존 dual로는 거절됐고
다른 existing Native dual로는 모두 통과했다. 올바른 인증이 존재한다는 것과
그 인증을 싸게 찾을 수 있다는 것은 다른 질문이다.

선택할 통합 가설은 **Goal-Conditioned, Certificate-Aware Perspective Discovery**다.
새 source/goal에서 필요한 정보, 유효 invariant, 충분 상태, certificate 생성,
실행/복원/fallback budget을 함께 고려한다. 최소 support membership loss를
개선하거나 solver ID를 선택하는 것만으로 이 기능이 생기지 않는다.

지금은 새 architecture를 구현하지 않는다. 변수를 줄여도 Strong Native보다
경제적인지를 아직 모르는 영역에 모델을 추가하면 North Star에서 멀어진다.
새 학습을 시작하려면 adequate representation, strong native headroom,
symbolic discovery의 residual gap, 구체적인 학습 결정, 권한/계보, independent
motif/composition 평가, 모든 실패 비용의 기록이라는7조건을 함께 충족해야 한다.

KEEP 자산은 기존 verifier/IR/native/proof/Perspective/experience/data rights다.
Variable cardinality는 확인된 표현 제약이나 단독 해결책으로 선정하지 않는다.
Relational model, compute-aware abstention, certificate-aware neural loss를
동시에 구현하지 않는다. 유일한 다음 우선 질문은 **무료 dual 없이도 충분
표현의 인증·실행이 강한 native보다 실제로 저렴한가**다.
