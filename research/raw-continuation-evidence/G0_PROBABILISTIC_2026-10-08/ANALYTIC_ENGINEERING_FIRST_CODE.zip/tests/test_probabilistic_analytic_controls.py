"""Goal/source mutations and exact native arithmetic, not performance evidence."""
from pathlib import Path
import unittest
from experiments import probabilistic_analytic_controls as c

BASE=Path(__file__).resolve().parents[3]/'Continuation/G0_PROBABILISTIC_2026-10-08/native-inputs'


class AnalyticNativeTests(unittest.TestCase):
    def bundle(self,kind):
        names={'coupon':('coupon','coupon.5-2.pgcl','coupon.props'),
               'egl':('egl','egl.prism','egl.props'),
               'herman15':('herman','herman.15.prism','herman.props')}
        family,model,props=names[kind]
        return (BASE/family/model).read_bytes(),(BASE/family/props).read_bytes()

    def test_two_exact_coupon_methods(self):
        # Arithmetic identities are fixtures, not new independent benchmark tasks.
        for n in range(1,9):
            for draws in range(1,5):
                self.assertEqual(c.coupon_batches(n,draws),c.coupon_occupancy(n,draws))

    def test_original_opened_goals(self):
        for kind,params,expected in [('coupon',{'B':5},'751/126'),
                                     ('egl',{'N':5,'L':2},'33/64'),
                                     ('herman15',{},'100/3')]:
            result=c.bound_native_control(kind,*self.bundle(kind),goal=c.GOALS[kind],parameters=params)
            self.assertEqual(result['output'],expected)
            self.assertFalse(result['learned_discovery'])
            self.assertEqual(result['performance'],'NOT_MEASURED')

    def test_original_transition_mutation_refused(self):
        model,props=self.bundle('egl')
        with self.assertRaises(ValueError):
            c.bound_native_control('egl',model.replace(b'0.5',b'0.4',1),props,goal='unfairA',parameters={'N':5,'L':2})

    def test_original_goal_and_property_mutation_refused(self):
        model,props=self.bundle('coupon')
        with self.assertRaises(ValueError):
            c.bound_native_control('coupon',model,props,goal='collect_all',parameters={'B':5})
        with self.assertRaises(ValueError):
            c.bound_native_control('coupon',model,props.replace(b'numberDraws',b'wrongReward'),goal='exp_draws',parameters={'B':5})

    def test_unknown_or_extra_parameters_refused(self):
        model,props=self.bundle('egl')
        for params in [{'N':1,'L':2},{'N':21,'L':2},{'N':5.0,'L':2},{'N':5,'L':0},{'N':5,'L':2,'accepted':True}]:
            with self.assertRaises(ValueError):
                c.bound_native_control('egl',model,props,goal='unfairA',parameters=params)

    def test_bound_is_not_exact_for_herman7(self):
        with self.assertRaises(ValueError): c.herman_max(7)
        model=(BASE/'herman/herman.7.prism').read_bytes()
        _,props=self.bundle('herman15')
        with self.assertRaises(ValueError): c.bound_native_control('herman15',model,props,goal='steps',parameters={})

    def test_caller_verdict_is_not_an_argument(self):
        with self.assertRaises(TypeError):
            c.bound_native_control('herman15',*self.bundle('herman15'),goal='steps',parameters={},accepted=True)


if __name__=='__main__':unittest.main()
