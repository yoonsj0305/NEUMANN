
Inductive List = cons {Int, List} | nil Unit;

@Combine al_inf = 100;

@Extract @Align al_head = \xs: List. 
    match xs with
      nil _ -> al_inf
    | cons {h, _} -> h
    end
;

single_pass = \v: List -> Int. 
    let run = (fix (
    \f: List -> Int. \xs: List. 
    match xs with
      nil _ -> 0
    | cons {h, t} -> 
        let tmp1 = (f t) in 
            + h tmp1
    end
)) in 
        \xs: List. 
        let tmp2 = (run xs) in 
            tmp2;

sum = fix (
    \f: List -> Int. \xs: List. 
    match xs with
      nil _ -> 0
    | cons {h, t} -> + h (f t)
    end
);

main = single_pass sum;
