# Missing evidence / intentional exclusions

각 항목은 원본 미확보·부분 보존·의도적 봉인을 구별한다. 원본 없음은 실패 판정이 아니다. Notion은 로컬 snapshot이며 최신 live 상태를 확인했다고 주장하지 않는다.

- **v0.0.1**: Separate Git experiment/run not recovered; v1 Notion report separately linked; no result inferred from successor.
- **v0.0.2**: Separate Git experiment/run not recovered; v1 Notion report separately linked; no result inferred from successor.
- **v0.0.3**: Separate Git experiment/run not recovered; v1 Notion report separately linked; no result inferred from successor.
- **v0.0.4**: Separate Git experiment/run not recovered; v1 Notion report separately linked; no result inferred from successor.
- **Initial-v0.1**: Only current/snapshot narrative; separate original research document/run unavailable.
- **Initial-v0.2**: Only current/snapshot narrative; separate original research document/run unavailable.
- **Initial-v0.3**: Only current/snapshot narrative; separate original research document/run unavailable.
- **Initial-v0.4**: Only current/snapshot narrative; separate original research document/run unavailable.
- **Initial-v0.5**: Only current/snapshot narrative; separate original research document/run unavailable.
- **Initial-v0.5.1**: Only current/snapshot narrative; separate original research document/run unavailable.
- **P1.2-validation**: D0 reports original raw ZIP not locally retained; documentary first outcome retained.
- **P1.3**: D0 reports original raw ZIP not locally retained; documentary first outcome retained.
- **P1.4**: D0 reports original raw ZIP not locally retained; documentary first outcome retained.
- **P1.5**: D0 reports original raw ZIP not locally retained; documentary first outcome retained.
- **P1.6**: D0 reports original raw ZIP not locally retained; documentary first outcome retained.
- **P1.7**: D0 reports original raw ZIP not locally retained; documentary first outcome retained.
- **P1.8**: D0 reports original raw ZIP not locally retained; documentary first outcome retained.
- **P1.9**: D0 reports original raw ZIP not locally retained; documentary first outcome retained.
- **P1.10**: D0 reports original raw ZIP not locally retained; documentary first outcome retained.
- **P1.11**: D0 reports original raw ZIP not locally retained; documentary first outcome retained.
- **P1.11.1**: D0 reports original raw ZIP not locally retained; documentary first outcome retained.
- **v0.0.39-first-result**: Preregistration recovered from unmerged branch; successful CI alone is not a recovered scientific result/first archive.
- **v100-v101-coefficients**: First archives contain metadata/ranking/witness but not original coefficient arrays; no regenerated surrogate accepted as original.
- **v087-first-confounded**: Original confounded archive lost; corrective execution distinct.
- **OCaml5-first-26-views**: Original archive lost; OCaml4.14 recovery is a distinct run.
- **Decision3-v098-v107-sealed**: Deliberate protected non-access; not missing evidence to reconstruct/open.
- **Formal-CPOG-checker**: Pinned Lean build timed out; only C prototype ran.
